Folder tb
 -- Contain the testbench files used to validated the components

Folder src
    -- detector: contain detector fault components
    -- RV: contain RISC-V core components
    -- RV_DL: contain basic components to integrate and test RV_DL
